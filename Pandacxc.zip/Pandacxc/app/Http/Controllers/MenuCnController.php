<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use app;

use App\Menucn;
use App\Menu;

use View;

class MenuCnController extends Controller
{
 
 ////////////
//Show all Chinese Menus  
    public function showChineseMenus()
    {
    	//$menus = NEW Menucn;
    	$menus = Menucn::All();
    	return View::make('Admin.Menu_CN_Form', array( 'menus'  => $menus ));	
    	
    } 
    
 /*
|--------------------------------------------------------------------------
| Pass the English ingredients which has been split into array
| Find Chinese translation for menu ingredients one by one.	
| Return String, which combine all chinese ingredients
|--------------------------------------------------------------------------
|
|
*/   
    //////////// 
//Find Chinese translation for menu ingredients one by one.	
	 Public Static function FindCnMenu($menusplits)
 	{
		// Chinese ingredents
   		$CnMenuList ="";
   
		// foreach ingredent, look for the chinese name from 'menuscn' table
   		 foreach ($menusplits as $menusplit) {
    			if( !empty($menusplit)  ){
    				$CnMenu = Menucn::where('name',$menusplit ) -> first();
    		
    					if( !empty($CnMenu  -> name_cn)  ){
    							$CnMenuList = $CnMenuList . ',' . $CnMenu -> name_cn;
    					}
    			}
   		};
  
  		//return value has ',' in the front, get rid of it
		$a = substr( $CnMenuList,1, -1 );
		$b = substr( $CnMenuList,-1 );
   		$CnMenuList = $a . $b;
  
    return $CnMenuList;
	}
	
	

 /*
|--------------------------------------------------------------------------
| Get Chinese translation for menu, 
| if not found, add English name with empty Chinese to table 'menuscn'
|--------------------------------------------------------------------------
|
|
*/  
	 public function FindEmptyChineseMenu($theResID)
 	{
 	
		//Get all menus from table 'menus' by resturant ID
		$Menus = Menu::where('ResID',$theResID) -> get();
		$MenuToBeTranslated = array();
	
		//For each course, get everything
		foreach ($Menus as $Menu){
		
			// split ingredients
			$MenuList = explode( ',', $Menu -> ingredients );
			// Add ingredients one by one to the list 
			foreach ($MenuList as $a ){
				array_push( $MenuToBeTranslated, $a );
			}
		}
		 
		array_unique( $MenuToBeTranslated );
		 
		 
		foreach ( $MenuToBeTranslated as $b){
			$MenuExist = Menucn::where('name',$b) -> first();
			if ( !$MenuExist ){
				$MenuCN = NEW Menucn;
				$MenuCN -> name = $b; 
				$MenuCN -> save();
			}
		 
		 }			
 	
		return redirect('admin/menu-tanslateto-chinese');	 	
 	}	
 	
 	

 /*
|--------------------------------------------------------------------------
| Only display view for one resturant with empty chinese translation
|--------------------------------------------------------------------------
|
|
*/   	
 	public function displayEmptyChineseMenuForm($theResID)
 	{
 		self::FindEmptyChineseMenu($theResID);
 		return redirect('admin/resturant-menu-add/'.$theResID);
 	
 	}


 /*
|--------------------------------------------------------------------------
| Show ingredients which Chinese translation is empty  
|--------------------------------------------------------------------------
|
|
*/

    public function showEmptyChineseMenus()
    {
    	$menus = Menucn::where('name_cn','=','')
    					-> orwhereNull('name_cn') 
    					-> get();
    	//$menus = Menucn::whereNull('name_cn') -> get();
    	return View::make('Admin.Menu_CN_Empty', array( 'menus'  => $menus ));	
    	
    }	
    
    
/*
|--------------------------------------------------------------------------
| Upload data from R_Menu_Form to databse   
|--------------------------------------------------------------------------
|
|
*/        
	public function addChineseMenus(Request $request)
	{
	
		$this->validate($request, [
        'name' 			=> 'required|unique:menucn|max:30',
        'name_cn'		=> 'required|max:50',
        'discription'	=> 'max:200',
       
    	]);
    	
   		$Menu_cn = NEW Menucn;
   		
   		//trim() — Strip whitespace (or other characters) from the beginning and end of a string
   		$Menu_cn -> name =  strtolower( trim( $request->input('name') ) );
   		$Menu_cn -> name_cn =  $request->input('name_cn');
   		$Menu_cn -> discription =  $request->input('discription') ;
		$Menu_cn -> save();
		
		return redirect('admin/menu-chinese-form');
		
	}
	
    
/*
|--------------------------------------------------------------------------
|Upload data from Menu_CN_Empty to databse menuscn   
|--------------------------------------------------------------------------
|
|
*/	  	
	public function UpdateEmptyChineseMenus(Request $request)
	{		
    	$MenuEmpties = Menucn::where('name_cn','=','') 
    						-> orwhereNull('name_cn')
    						-> get();
    	//$MenuEmpties = Menucn::whereNull('name_cn') -> get();

    	foreach( $MenuEmpties as $MenuEmpty ){
    	
    		$MenuEmpty->name_cn = $request->input('cname_' . $MenuEmpty->id ) ;
    		$MenuEmpty->discription =$request->input('discription_' . $MenuEmpty->id );
    		$MenuEmpty -> save();
    
    	}
    	
    	return redirect('admin/menu-chinese-form');
    	
    }
    
    
/*
|--------------------------------------------------------------------------
|Open the view for update translation - only one  
|--------------------------------------------------------------------------
|
|
*/	     
    public function updateTranslationForm($theTranID)
    {
    	$translation = Menucn::find($theTranID);
    	return View::make('Admin.Translation_Update', array( 'translation'  => $translation));
    
    }
	
/*
|--------------------------------------------------------------------------
| update translation to database - only one  
|--------------------------------------------------------------------------
|
|
*/	     
    public function	updateTranslationByID(Request $request, $theTranID)
    {
    	$translation = Menucn::find($theTranID);
    	$translation -> name = $request->input('name');
    	$translation -> name_cn = $request->input('name_cn');
    	$translation -> discription = $request->input('discription');
    	$translation -> save();
    	
    	return redirect('admin/menu-chinese-form');
    	
    
    }
	
/*
|--------------------------------------------------------------------------
| Open the view for input English menu by sentence  
|--------------------------------------------------------------------------
|
|
*/	
	public function sentenceTranslationForm()
	{
    	return View::make('Admin.Translation_Add_BySentence');

	}
	
/*
|--------------------------------------------------------------------------
| give one $sentence,  spit them to word by word, and add to translation table
|--------------------------------------------------------------------------
|
|
*/	
	public function sentenceToTranslationDB($sentence)
	{
		
       $MenuToBeTranslated = array(); 
        //use , to split
		if(  str_contains($sentence, ',')  ){
		
			$list = explode( ',',$sentence );
		}
		//use space to split
		else{
			$list = explode( ' ',$sentence );
		}
		
		
		// Add ingredients one by one to the list 
		foreach ($list as $a ){
			//trim() — Strip whitespace (or other characters) from the beginning and end of a string
			$a =  strtolower( trim( $a)  );
			if( $a!='' ){
				array_push( $MenuToBeTranslated, $a );
		   	}	
		}	
		
		array_unique( $MenuToBeTranslated );
		 
		 
		foreach ( $MenuToBeTranslated as $b){
			$MenuExist = Menucn::where('name',$b) -> first();
			if ( !$MenuExist ){
				$MenuCN = NEW Menucn;
				$MenuCN -> name = $b; 
				$MenuCN -> save();
			}
		 
		 }	
		 
		 
		 
		 		
	}
	
	
/*
|--------------------------------------------------------------------------
|  get data from view'Translation_Add_BySentence', add to Menucn table
|--------------------------------------------------------------------------
|
|
*/		public function sentenceTranslation(Request $request)
	{
		$sentence = $request -> input('sentence');
		self::sentenceToTranslationDB($sentence);
		
		return redirect('admin/menu-tanslateto-chinese');
	
	}
	
}
