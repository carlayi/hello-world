<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Resturant;
use App\Menu;
use App\Menucat;
use App\Menulike;

use View;
use App\Http\Controllers\MenuCnController;

class ResturantMenuController extends Controller
{

/*
|--------------------------------------------------------------------------
| Get Resturant Infomation by resturnat ID
|--------------------------------------------------------------------------
|
|
*/
	
	public function getResturantInfo($theResID)
    {	
    
    //Find Resturant from database by ID
   	//$Resturant = NEW Resturant;
   	$Resturant = Resturant::where('id',$theResID)->first();
   	
	return $Resturant;
    
	}
/*
|--------------------------------------------------------------------------
| Get Resturant Infomation by resturnat ID
|--------------------------------------------------------------------------
|
|
*/	
	public function userResturantIndex($theResID)
    {	
    
    	return View::make('R_Menu', array( 
			//'theResID' => $theResID , 
			'resturant' => self::getResturantInfo($theResID) ,
			'menus'  => self::getResturantCnMenus($theResID), 
   
			));	
    
	}
	
	
/*
|--------------------------------------------------------------------------
| Get Resturant Menus (all menus) by resturnat ID, display with sequence
|--------------------------------------------------------------------------
|
|
*/
	
	public function getResturantMenu($theResID)
	{
		
    $Menus = Menu::where('ResID',$theResID)
    			-> orderBy('seq','asc')
    			-> orderBy('catID','asc')
    			->get();
    
  	return $Menus;
  	
	}


/*
|--------------------------------------------------------------------------
| Get Resturant Category and Menus(both English and Chinese) by Resturant ID
|--------------------------------------------------------------------------
|
*/

	public function getResturantCnMenus($theResID)
	{
		//find English menus
    	$menus = self::getResturantMenu( $theResID);
    	
    	
    	foreach( $menus as $menu ){
			//get category name by category id
			$catSet = Menucat::where('id',$menu -> catID ) -> first() ;
			if($catSet != NULL){
				$catName = $catSet -> name . "<" . $catSet -> name_cn . ">" ;
			}
			$menu -> catName = $catName;
			
			//get chinese ingredients name. 
			$menusplits = explode( ',', $menu->ingredients );
			$menu -> ingredients_cn = MenuCnController::FindCnMenu($menusplits);
			
			
		}
		
		return $menus;		
    }			
	
	
/*
|--------------------------------------------------------------------------
| Open R_Menu view by resturant id	 (view for user - no input form)
|--------------------------------------------------------------------------
|
*/	
/*	
	public function displayResturantMenus($theResID)
    {	

		return View::make('R_Menu', array( 
		'theResID' => $theResID , 
		'Resturant' => self::getResturantInfo($theResID) ,
		'menus'  => self::getResturantCnMenus($theResID), 
   
		));	
    
	}
*/
/*
|--------------------------------------------------------------------------
| Open R_Menu_Form view by resturant id  (view for admin - with the input form)
|--------------------------------------------------------------------------
|
*/		

	public function displayResturantMenusForm($theResID)
    {	

    	//Find All category
   		$allcats = Menucat::all();

		return View::make('Admin.R_Menu_Form', array( 
			'theResID' 	=> $theResID , 
			'resturant' => self::getResturantInfo($theResID) ,
			'menus'  	=> self::getResturantCnMenus($theResID), 
			
			//Values use in the Form
			'allcats'	=> $allcats,
			'seq' 		=> self::getNextMenuSeqNo($theResID) + 1 ,
			'defaultCatID' 	=> self::getDefaultCatID($theResID)
   		
		));	
    
	}

/*
|--------------------------------------------------------------------------
| Give a Resturant ID, 
| Return the last menu seqence no 
|--------------------------------------------------------------------------
|
*/	
	public function getNextMenuSeqNo($theResID)
    {
    	$seq = Menu::where('ResID',$theResID) ->max('seq');
		return  $seq;
    }	
    	
	public function getDefaultCatID($theResID)
	{
		$seq = self::getNextMenuSeqNo($theResID);
    	//Default value for next category
    	$lastMenu = Menu::where('ResID',$theResID) 
    				->Where('seq',$seq)
    				->first();
    	return $lastMenu -> catID;
	}



/*
|--------------------------------------------------------------------------
| Upload data from R_Menu_Form to databse 'menus'
|--------------------------------------------------------------------------
|
*/
	public function uploadMenus(Request $request,$theResID)
    {

    $Menu = NEW Menu;
    $Menu -> ResID		= $theResID; 
    $Menu -> seq 		= $request->input('seq');
    $Menu -> catID 		= $request->input('catID');  
    $Menu -> name 		= $request->input('name'); 
    $Menu -> ingredients = $request->input('ingredients'); 
    $Menu -> save();
    
    //displcay the updated data to current R_Menu_Form 
	return $this->displayResturantMenusForm($theResID);
    }
 

/*
|--------------------------------------------------------------------------
| Open the View of update Resturant Menu
|--------------------------------------------------------------------------
|
*/
	public function openUpdateResturantMenuPage($theResID)
	{
		//Find All category
   		 $allcats = Menucat::all();
    
		return View::make('Admin.R_Menu_Update', array( 
		'theResID' => $theResID , 
		'resturant' => self::getResturantInfo($theResID) ,
		//'menus'  => self::getResturantMenu($theResID),
		'menus'  => self::getResturantCnMenus($theResID),
		 
		'allcats' => $allcats,
   
		));	
	
	}	   
	

	
/*
|--------------------------------------------------------------------------
| Resturant Menu Update to Database
|--------------------------------------------------------------------------
|
*/	
	public function UpdateResturantMenuToDB(Request $request, $theResID)
	{
		$Menus = Menu::where('ResID',$theResID) -> get();

    	foreach( $Menus as $Menu ){
    	
    		$Menu->seq = $request->input('seq_' . $Menu->id ) ;
    		$Menu->catID =$request->input('catID_' . $Menu->id );
    		$Menu->name =$request->input('name_' . $Menu->id );
    		$Menu->ingredients =$request->input('ingredients_' . $Menu->id );
    		
    		$Menu -> save();
    
    	}
    	
    	return redirect('admin/resturant-menu-update/'.$theResID);
    	
	}	


/*
|--------------------------------------------------------------------------
|  Menu Like +1
|     --- Check the user IP has liked the menu before, like +1 if not
|--------------------------------------------------------------------------
|
*/	

	public function addMenuLike(Request $request, $theResID,$theMenuID){
		
		$menu = Menu::find($theMenuID);
		if( $menu ){
			//Check if the same user IP 'like' the menu before 
			$ipCheck = Menulike::where('menuID',$theMenuID)
							->where('userIP',$request -> ip() )
							->get();
			if ( $ipCheck -> isEmpty() ){
				$menu -> likes = $menu -> likes  + 1 ;
				$menu -> save();
				
				$newUserIP = NEW Menulike;
				$newUserIP -> menuID = $theMenuID;
				$newUserIP -> userIP = $request -> ip();
				$newUserIP -> save();
			} 				
		
			
		
		}
	
		return redirect('resturants/'.$theResID);
	}
	
	public function uploadFile(Request $request){
	
		$destinationPath = public_path().sprintf("\uploads\%s\\", str_random(8));
		
		if ($request->hasFile('file')) {
			if( $request->file('file')->move($destinationPath) ) {
				return redirect('upload-menu');
			}else{
				return redirect('admin');
			};
		}
		
		
		
	}
	
}
