<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Contracts\Validation\Validator;

use App\Http\Requests;

use App\Resturant;
use App\Category;
use View;


class ResturantController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
  
 	public function __construct()
    {
        $this->middleware('auth');
    }

   //   NOT USE ANYMORE
   // List All Resturants
	public function showAllResturant()
    {
    	$resturants = Resturant::all();
    	
    	return View::make('R_Info', array('resturants' => $resturants ));
    	
	}
	
	
	
//List All Resturants, then show the add resturant form
	public function showResturantForm()
    {
    	$resturants = Resturant::all();
    	
    	
    	
    	//**
    	
    	//get every restruant's type id, use id to get type name
    	foreach( $resturants as $resturant){
    	
    	$catIDs = explode( ',', $resturant -> type );
    	$resturant -> typeName = CategoryController::getCategoryNameByIDs($catIDs) ;	
    	
    	}
    	
    	
    	// Resturant types for selections in the form
    	$resturantTypes = Category::where('type','resturantType') -> get();
    	
    	return View::make('Admin.R_Info_Form', array(
    		'resturants' => $resturants, 
    		'resturantTypes' => $resturantTypes
    	));
    	
    	
	}
	
//////// Added on 20/04/2016
// Delete Resturant by id, then back to the Resturant List
	public function deleteResturantByID($theResID)
	{
	
		$Resturants = Resturant::where('id',$theResID) -> delete();
		return redirect('admin/resturant-add');
    	
    	
	}




//
	public function findResturantToBeUpdate($theResID)
	{
		//$theResID = $Resturant->id
		$resturant = Resturant::where('id',$theResID) -> first();
		
		// Resturant types for selections in the form
    	$resturantTypes = Category::where('type','resturantType') -> get();
		
		return View::make('Admin.R_Info_Update_Form', array(
				'resturant'		 => $resturant ,
				'resturantTypes' => $resturantTypes
		));
    	
	}
	
	public function updateResturantByID(Request $request,$theResID)
	{
		$this->validate($request, [
        'name' 		=> 'required|max:100',
        'address'	=> 'required|max:200',
        'tel'		=> 'required|max:30',
        'country'	=> 'required|max:30',
        'city'		=> 'required|max:50',
       
        
    	]);
    	
		$resturant = Resturant::find($theResID);
		
		$resturant->name    = $request->input('name');
		$resturant->address = $request->input('address');
		$resturant->tel     = $request->input('tel');
		$resturant->country = $request->input('country');
		$resturant->city    = $request->input('city');
		$resturant->type    = implode(",",$request->input('resturnatType'));
		
		$resturant->save();
		
		
		return redirect('admin/resturant-add');
	}

//Get Data from R_Info_Form, save them to Database resturants	
	public function addResturants(Request $request)
	{
	    $this->validate($request, [
        'name' 		=> 'required|max:100',
        'address'	=> 'required|max:200',
        'tel'		=> 'required|max:30',
        'country'	=> 'required|max:30',
        'city'		=> 'required|max:50',
        
        
    	]);
	
	/*
		//Validate Input Data
		$validator = Validator::make($request->all(), [
        'name' 		=> 'required|max:30',
        'address'	=> 'required',
        'tel'		=> 'required',
        'country'	=> 'required',
        'city'		=> 'required',
        'type'		=> 'required',
   		]);
		
		if ($validator->fails()) {
        return redirect('Admin/Resturant-Info-Form')
            ->withInput()
            ->withErrors($validator);
    	}
	*/
		//Validation Passed, SAVE DATA TO Database
		$Resturant = NEW Resturant;
		$Resturant->name    = $request->input('name');
		$Resturant->address = $request->input('address');
		$Resturant->tel     = $request->input('tel');
		$Resturant->country = $request->input('country');
		$Resturant->city    = $request->input('city');
		$Resturant->type    = implode(",",$request->input('resturnatType'));
		
		$Resturant->save();
	
		return self::showResturantForm();
	
	}	

   
   
}
