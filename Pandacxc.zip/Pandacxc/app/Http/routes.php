<?php
use App\Resturant;

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('about', function()
{
    return 'ABOUT content';
});

	Route::get('/', function () {
        return view('welcome');
    });
    
    
    

    Route::get('/qrcode', function () {
        return view('QRtest');
    });
    
    Route::get('/test', function () {
 		
      // return str_contains('Prawn ,ravioli in a lobster sauce with aged Parmesan cream',',');
        
        $sentence = 'Prqwn ,ravioli in a lobster sauce with aged Parmesan cream';
        
       if ( str_contains($sentence, ',') ){
       	return "contain";
       }else{
       return "not contain";
       };
    });
    
    
/*   

	Route::get('/', function () {
        return view('welcome');
    })->middleware('guest');
    
    
     
	Route::get('/admin',  ['middleware' => 'auth', function(){
		return View::make('Admin.Admin_Home');
	}]);

	Route::get('admin/resturant-add', [
		'middleware' => 'auth',
		'uses' => 'ResturantController@showResturantForm' 
	]);
*/

Route::group(['middleware' => ['auth']], function () {

	Route::get('/admin', function(){
		return View::make('Admin.Admin_Home');
	});

	Route::get('admin/resturant-add','ResturantController@showResturantForm');
	Route::post('admin/resturant-add','ResturantController@addResturants');

	Route::get('admin/resturant-update/{theResID}','ResturantController@findResturantToBeUpdate');
	Route::post('admin/resturant-update/{theResID}','ResturantController@updateResturantByID');

	Route::get('admin/resturant-delete/{theResID}', 'ResturantController@deleteResturantByID' );

	Route::get('admin/resturant-menu-add/{theResID}','ResturantMenuController@displayResturantMenusForm');
	Route::post('admin/resturant-menu-add/{theResID}','ResturantMenuController@uploadMenus');

	Route::get('admin/resturant-menu-update/{theResID}','ResturantMenuController@openUpdateResturantMenuPage');
	Route::post('admin/resturant-menu-update/{theResID}','ResturantMenuController@UpdateResturantMenuToDB');

	Route::get('admin/menu-tanslate/{theResID}','MenuCnController@FindEmptyChineseMenu');

	Route::get('admin/menu-tanslateto-chinese','MenuCnController@showEmptyChineseMenus');
	Route::post('admin/menu-tanslateto-chinese','MenuCnController@UpdateEmptyChineseMenus');

	Route::get('admin/menu-chinese-form','MenuCnController@showChineseMenus');
	Route::post('admin/menu-chinese-form','MenuCnController@addChineseMenus');

	Route::get('admin/translation-update/{theTranID}','MenuCnController@updateTranslationForm');
	Route::post('admin/translation-update/{theTranID}','MenuCnController@updateTranslationByID');
	
	Route::get('admin/translation-sentence-add','MenuCnController@sentenceTranslationForm');
	Route::post('admin/translation-sentence-add','MenuCnController@sentenceTranslation');
});

Route::auth();
Route::get('upload-menu',function () {
        return view('Menu_Upload');
    });
Route::post('upload-menu','ResturantMenuController@uploadFile');
/*
Route::get('/resturants/{country}', 'ResturantController@showAllResturant');
Route::get('/resturants/{country}/{city}', 'ResturantController@showAllResturant');
*/

Route::get('/resturants/{theResID}', 'ResturantMenuController@userResturantIndex');

Route::post('/resturants/{theResID}/add-menu-like/{theMenuID}', 'ResturantMenuController@addMenuLike');

Route::get('/home', 'HomeController@index');

