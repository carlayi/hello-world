<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Menucn extends Model
{
    protected $table = 'menucn';
}
