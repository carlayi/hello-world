<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UpdateResturant extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('resturants', function ($table) {
   		 	$table->string('tel',30)->nullable() ->change();
   		 	$table->string('state',20)->nullable() ->change();
   		 	$table->string('type',50)->nullable() ->change();
		});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
