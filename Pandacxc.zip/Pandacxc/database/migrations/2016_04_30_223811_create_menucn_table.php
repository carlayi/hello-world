<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMenucnTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('menucn',function($thetable)
		{
			$thetable->increments('id');
			$thetable->string('name',40);
			$thetable->string('name_cn',50)->nullable();
			$thetable->string('discription',200)->nullable();
			$thetable->string('photo')->nullable();
			$thetable->timestamps();
		});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('menucn');
    }
}
