<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UpdateResturantColumnLength extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

    	 Schema::table('resturants', function ($table) {
   		 	$table->string('name',100) ->change();
   		 	$table->string('address',300)->change();
   		 	$table->string('country',30)->change(); 
   		 	$table->string('city',50)->change();
   		 	$table->integer('menu_format_type');
		});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
