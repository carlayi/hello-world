@extends('layouts.userPage')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
        
            <div class="panel panel-primary">
                
				<div class="panel-heading">
					<h3 class="panel-title">Country</h3>
				</div>
                <div class="panel-body">
						@foreach ($resturants as $resturant) 
						<ul>
							<li>{{ $resturant->id }}</li>
							<a href="{{ URL::to('resturants', $resturant->id) }}">  {{$resturant->name }} </a>
							<li>Resturant Name: {{$resturant->name }}</li>
							<li>Resturant Type: {{$resturant->typeName }}</li>
							<li>Address: {{$resturant->address }} , {{ $resturant->city }} , {{ $resturant->country }}</li>
							<li>Tel: {{ $resturant->tel }}</li>
							<hr>
							
 						</ul>
						@endforeach
				</div>
			</div>
 		</div>
    </div>
</div>
@endsection