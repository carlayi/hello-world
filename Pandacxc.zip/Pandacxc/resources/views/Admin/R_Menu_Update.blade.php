@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">
					<h3 class="panel-title">Admin:  Resturant Menu Update</h3>
				</div>
                <div class="panel-body">


				<ul>
					<li>{{ $resturant->id }}</li>
					<li>Resturant Name: {{$resturant->name }}</li>
					<li>Resturant Type: {{$resturant->typeName }}</li>
				</ul>


				@foreach ($menus as $menu) 
				
					<p>{{ $menu->seq }}  {{ $menu->name }}  </p> 
					<p>{{ $menu->catName }} </p>
					<p>{{ $menu->ingredients }}  </p>  
					<p>{{ $menu->ingredients_cn }}</p>
				<hr>
				@endforeach	



				<h2>Menu Update: </h2>
				
				
				<form action="{{ url('admin/resturant-menu-update/'.  $theResID ) }}" method="POST" >
							 {!! csrf_field() !!}
							 
						 
				<?php $cat = "" ?>
			
				@foreach ($menus as $menu) 
					<div class="form-group">
						<label for="sequence">Sequence No. </label>
						<input type="text" name="{{ 'seq_'. $menu->id }}" value={{ $menu->seq }} />
					</div>
					
				
					<!--Course category-->
					<div class="form-group">
						<label for="catLabel">Course Category</label>
						@foreach( $allcats  as $cat )
					
							<!-- Set default value for category-->
							@if($cat->id == $menu->catID )
								<input type="radio" name={{'catID_'. $menu->id }} value= {{$cat -> id}} checked /> {{  $cat -> name }} 
							@else
								<input type="radio" name={{'catID_'. $menu->id }} value= {{$cat -> id}} /> {{  $cat -> name }} 
							@endif 
			
						 @endforeach
					</div>	 
						 
					
					<div class="form-group">
						<label for="courseName">Course Name </label>
						<input type="text" name="{{ 'name_'. $menu->id }}" value={{ $menu->name }} />
					</div> 

					<div class="form-group">
						<label for="ingredients">Ingredients</label>
						<input type="text" name="{{ 'ingredients_'. $menu->id }}" value={{ $menu->ingredients }} class="form-control"  />
					</div> 
			
				<hr> 
				@endforeach	


				<input type="submit" name="submit" value="Update">
	
				</form>

       
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
