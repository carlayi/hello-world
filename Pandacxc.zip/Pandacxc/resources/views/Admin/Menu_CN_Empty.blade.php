@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
        You are logged in!
            <div class="panel panel-primary">
                
				<div class="panel-heading">
					<h3 class="panel-title">Admin: 显示没有翻译的食材</h3>
				</div>
                <div class="panel-body">
						<form action="{{ url('admin/menu-tanslateto-chinese') }}" method="POST" >
									{!! csrf_field() !!}
	
							
							@foreach ($menus as $menu) 
								<h1>{{ $menu->name }} </h1>
								
								<div class="form-group">
									<label for="enName">Chinese Name</label>
									<input type="text" name= "{{ 'cname_'. $menu->id }}" value=""  class="form-control">
								</div>
								
								<div class="form-group">
									<label for="enName">Description</label>
									<input type="text" name= "{{ 'discription_'. $menu->id }}" value=""  class="form-control">
								</div>
								
								
							
							@endforeach	
						</table>
							
		
					<input type="submit" name="submit" value="Update" class="btn btn-primary">
	
					</form>	

				</div>
			</div>
 		</div>
    </div>
</div>
@endsection