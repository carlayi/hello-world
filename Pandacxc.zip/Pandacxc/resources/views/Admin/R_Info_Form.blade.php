@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
        You are logged in!
            <div class="panel panel-primary">
                
				<div class="panel-heading">
					<h3 class="panel-title">Restrants List</h3>
				</div>
                <div class="panel-body">
                    <ul>
                    	@foreach ($resturants as $resturant) 
						<ul>
							<li>{{ $resturant->id }}</li>
							<li>Resturant Name: {{$resturant->name }}</li>
							<li>Resturant Type: {{$resturant->typeName }}</li>
							<li>Address: {{$resturant->address }} , {{ $resturant->city }} , {{ $resturant->country }}</li>
							<li>Tel: {{ $resturant->tel }}</li>
							
							
 						</ul>
                    
						<h4>操作</h4>
					  	<ul>
							<li>
								<a href="{{ URL::to('admin/resturant-update', $resturant->id) }}"> Update Resturant Info</a>
							</li>
					 		<li>
								<a href="{{ URL::to('admin/resturant-delete', $resturant->id) }}"> Delete Resturant</a>
							</li>
							<!--
							<form action="{{ url('Admin/Resturant-Delete/'.$resturant->id) }}" method="POST">
								{!! csrf_field() !!}
								{!! method_field('DELETE') !!}

								<button type="submit" class="btn btn-danger">
									<i class="fa fa-trash"></i> Delete Resturant
								</button>
							</form>
							-->
		
							<li>		 		
								<a href="{{ URL::to('admin/resturant-menu-add', $resturant->id) }}"> View / Add Menus </a>
							</li>
							<li>
								<a href="{{ URL::to('admin/resturant-menu-update', $resturant->id) }}"> Update Menus </a>
							</li>
						</ul>
					<hr>
					@endforeach	
					</ul>
				</div>
				</div>
				
				
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title">Add a Resturant</h3>
					</div>
					<div class="panel-body">
					
						@if (count($errors) > 0)
							<div class="">
								<ul>
									@foreach ($errors->all() as $error)
										<li>{{ $error }}</li>
									@endforeach
								</ul>
							</div>
						@endif


					
						<form action="{{ url('admin/resturant-add') }}" method="POST" >
							 {!! csrf_field() !!}
							<div class="form-group">
								<label for="name">Resturant Name</label>
								<input type="text" name="name" value="" class="form-control"/>
							</div>
					
							<div class="form-group">
								<label for="country">Country</label>
								<input type="text" name="country" value="" class="form-control"/>   
								<label for="city">City</label>
								<input type="text" name="city" value="" class="form-control"/>    
							</div>
					
					
							<div class="form-group">
								<label for="address">Resturant Address</label>
								<input type="text" name="address" value="" class="form-control"  />   
							</div>
					
							<div class="form-group">
								<label for="tel">Returant Phone No.</label>
								<input type="tel" name="tel" value="" class="form-control" /> 
						
							</div>
					
							<div class="form-group">
								<label for="tel">Returant Type:</label>
								
								@foreach( $resturantTypes as $resturantType ) 
									<label class="checkbox-inline"> 		
											  <input type="checkbox" name="resturnatType[]" id={{ "resturnatType_" .  $resturantType ->id }} 
											  value={{ $resturantType ->id }}> {{ $resturantType ->name }}
									</label>
 								@endforeach
 								
							</div>
							
							
								<input type="submit" name="submit" value="Add Resturant" class="btn btn-primary">
				
							</div>
						</form>   
               		</div>
                </div>
                
            
        </div>
    </div>
</div>
@endsection





