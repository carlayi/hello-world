@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
      
            <div class="panel panel-primary">
                
				<div class="panel-heading">
					<h3 class="panel-title">Admin: 输入整句英文，系统把它逐个添加到翻译中表格</h3>
				</div>
                <div class="panel-body">
				
				
				
				<form action="{{ url('admin/translation-sentence-add') }}" method="POST" >
					{!! csrf_field() !!}

					<div class="form-group">
					<label for="enSentence">English Menu Sentence</label>
					<input type="text" name="sentence" value="" class="form-control"  />
					</div>

					<input type="submit" name="submit" value="Split to Words" class="btn btn-primary">
				</form>


				</div>
			</div>
 		</div>
    </div>
</div>
@endsection