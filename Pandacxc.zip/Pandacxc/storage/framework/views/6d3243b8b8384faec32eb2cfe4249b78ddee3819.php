<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
      
            <div class="panel panel-primary">
                
				<div class="panel-heading">
					<h3 class="panel-title">Admin: 显示没有翻译的食材</h3>
				</div>
                <div class="panel-body">
				
				<table class="table table-striped">	
					<tr>
						<td>English Name</td>
						<td>Chinese Name</td>
						<td>Chinese Description</td>
					</tr>
					<tr>
						<td><?php echo e($translation->name); ?> </td> 
						<td><?php echo e($translation->name_cn); ?>  </td> 
						<td><?php echo e($translation->discription); ?>  </td>   
					</tr>
				</table>
				
				<?php if(count($errors) > 0): ?>
				<div class="">
				<ul>
				<?php foreach($errors->all() as $error): ?>
				<li><?php echo e($error); ?></li>
				<?php endforeach; ?>
				</ul>
				</div>
				<?php endif; ?>
				
				<form action="<?php echo e(url('admin/translation-update/'.$translation -> id)); ?>" method="POST" >
					<?php echo csrf_field(); ?>


					<div class="form-group">
					<label for="enName">English Name</label>
					<input type="text" name="name" value="<?php echo e($translation -> name); ?>" class="form-control" />
					</div>

					<div class="form-group">
					<label for="cnName">Chinese Name</label>
					<input type="text" name="name_cn" value="<?php echo e($translation -> name_cn); ?>" class="form-control"/>
					</div>

					<div class="form-group">
					<label for="dicription">Dicription</label>
					<input type="text" name="discription" value="<?php echo e($translation -> discription); ?>" class="form-control" />
					</div>
					
					<input type="submit" name="submit" value="Update" class="btn btn-primary">
				</form>


				</div>
			</div>
 		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>