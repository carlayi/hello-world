<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">
					<h3 class="panel-title">Admin:  Resturant Menu Update</h3>
				</div>
                <div class="panel-body">


				<ul>
					<li><?php echo e($resturant->id); ?></li>
					<li>Resturant Name: <?php echo e($resturant->name); ?></li>
					<li>Resturant Type: <?php echo e($resturant->typeName); ?></li>
				</ul>


				<?php foreach($menus as $menu): ?> 
				
					<p><?php echo e($menu->seq); ?>  <?php echo e($menu->name); ?>  </p> 
					<p><?php echo e($menu->catName); ?> </p>
					<p><?php echo e($menu->ingredients); ?>  </p>  
					<p><?php echo e($menu->ingredients_cn); ?></p>
				<hr>
				<?php endforeach; ?>	



				<h2>Menu Update: </h2>
				
				
				<form action="<?php echo e(url('admin/resturant-menu-update/'.  $theResID )); ?>" method="POST" >
							 <?php echo csrf_field(); ?>

							 
						 
				<?php $cat = "" ?>
			
				<?php foreach($menus as $menu): ?> 
					<div class="form-group">
						<label for="sequence">Sequence No. </label>
						<input type="text" name="<?php echo e('seq_'. $menu->id); ?>" value=<?php echo e($menu->seq); ?> />
					</div>
					
				
					<!--Course category-->
					<div class="form-group">
						<label for="catLabel">Course Category</label>
						<?php foreach( $allcats  as $cat ): ?>
					
							<!-- Set default value for category-->
							<?php if($cat->id == $menu->catID ): ?>
								<input type="radio" name=<?php echo e('catID_'. $menu->id); ?> value= <?php echo e($cat -> id); ?> checked /> <?php echo e($cat -> name); ?> 
							<?php else: ?>
								<input type="radio" name=<?php echo e('catID_'. $menu->id); ?> value= <?php echo e($cat -> id); ?> /> <?php echo e($cat -> name); ?> 
							<?php endif; ?> 
			
						 <?php endforeach; ?>
					</div>	 
						 
					
					<div class="form-group">
						<label for="courseName">Course Name </label>
						<input type="text" name="<?php echo e('name_'. $menu->id); ?>" value=<?php echo e($menu->name); ?> />
					</div> 

					<div class="form-group">
						<label for="ingredients">Ingredients</label>
						<input type="text" name="<?php echo e('ingredients_'. $menu->id); ?>" value=<?php echo e($menu->ingredients); ?> class="form-control"  />
					</div> 
			
				<hr> 
				<?php endforeach; ?>	


				<input type="submit" name="submit" value="Update">
	
				</form>

       
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>