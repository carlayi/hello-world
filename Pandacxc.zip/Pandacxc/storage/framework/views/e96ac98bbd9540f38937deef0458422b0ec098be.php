<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
        You are logged in!
            <div class="panel panel-primary">
                
				<div class="panel-heading">
					<h3 class="panel-title">Restrants List</h3>
				</div>
                <div class="panel-body">
                    <ul>
                    	<?php foreach($resturants as $resturant): ?> 
						<ul>
							<li><?php echo e($resturant->id); ?></li>
							<li>Resturant Name: <?php echo e($resturant->name); ?></li>
							<li>Resturant Type: <?php echo e($resturant->typeName); ?></li>
							<li>Address: <?php echo e($resturant->address); ?> , <?php echo e($resturant->city); ?> , <?php echo e($resturant->country); ?></li>
							<li>Tel: <?php echo e($resturant->tel); ?></li>
							
							
 						</ul>
                    
						<h4>操作</h4>
					  	<ul>
							<li>
								<a href="<?php echo e(URL::to('admin/resturant-update', $resturant->id)); ?>"> Update Resturant Info</a>
							</li>
					 		<li>
								<a href="<?php echo e(URL::to('admin/resturant-delete', $resturant->id)); ?>"> Delete Resturant</a>
							</li>
							<!--
							<form action="<?php echo e(url('Admin/Resturant-Delete/'.$resturant->id)); ?>" method="POST">
								<?php echo csrf_field(); ?>

								<?php echo method_field('DELETE'); ?>


								<button type="submit" class="btn btn-danger">
									<i class="fa fa-trash"></i> Delete Resturant
								</button>
							</form>
							-->
		
							<li>		 		
								<a href="<?php echo e(URL::to('admin/resturant-menu-add', $resturant->id)); ?>"> View / Add Menus </a>
							</li>
							<li>
								<a href="<?php echo e(URL::to('admin/resturant-menu-update', $resturant->id)); ?>"> Update Menus </a>
							</li>
						</ul>
					<hr>
					<?php endforeach; ?>	
					</ul>
				</div>
				</div>
				
				
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title">Add a Resturant</h3>
					</div>
					<div class="panel-body">
					
						<?php if(count($errors) > 0): ?>
							<div class="">
								<ul>
									<?php foreach($errors->all() as $error): ?>
										<li><?php echo e($error); ?></li>
									<?php endforeach; ?>
								</ul>
							</div>
						<?php endif; ?>


					
						<form action="<?php echo e(url('admin/resturant-add')); ?>" method="POST" >
							 <?php echo csrf_field(); ?>

							<div class="form-group">
								<label for="name">Resturant Name</label>
								<input type="text" name="name" value="" class="form-control"/>
							</div>
					
							<div class="form-group">
								<label for="country">Country</label>
								<input type="text" name="country" value="" class="form-control"/>   
								<label for="city">City</label>
								<input type="text" name="city" value="" class="form-control"/>    
							</div>
					
					
							<div class="form-group">
								<label for="address">Resturant Address</label>
								<input type="text" name="address" value="" class="form-control"  />   
							</div>
					
							<div class="form-group">
								<label for="tel">Returant Phone No.</label>
								<input type="tel" name="tel" value="" class="form-control" /> 
						
							</div>
					
							<div class="form-group">
								<label for="tel">Returant Type:</label>
								
								<?php foreach( $resturantTypes as $resturantType ): ?> 
									<label class="checkbox-inline"> 		
											  <input type="checkbox" name="resturnatType[]" id=<?php echo e("resturnatType_" .  $resturantType ->id); ?> 
											  value=<?php echo e($resturantType ->id); ?>> <?php echo e($resturantType ->name); ?>

									</label>
 								<?php endforeach; ?>
 								
							</div>
							
							
								<input type="submit" name="submit" value="Add Resturant" class="btn btn-primary">
				
							</div>
						</form>   
               		</div>
                </div>
                
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>