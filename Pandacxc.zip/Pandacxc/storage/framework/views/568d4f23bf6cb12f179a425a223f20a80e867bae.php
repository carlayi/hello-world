<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
        
            <div class="panel panel-primary">
                
				<div class="panel-heading">
					<h3 class="panel-title">Admin Page: Resturant update</h3>
				</div>
                <div class="panel-body">

					<li><?php echo e($resturant->id); ?></li>
					<li> Resturant Name: <?php echo e($resturant->name); ?></li>
					<li> Resturant Address:  <?php echo e($resturant->address . ',' .  $resturant->city . ',' . $resturant->country); ?></li>
					<li> Resturant Phone No.: <?php echo e($resturant->tel); ?></li>

					<h1>Resturant Information Update</h1>


					<?php if(count($errors) > 0): ?>
						<div class="">
							<ul>
								<?php foreach($errors->all() as $error): ?>
									<li><?php echo e($error); ?></li>
								<?php endforeach; ?>
							</ul>
						</div>
					<?php endif; ?>



					<form action="<?php echo e(url('admin/resturant-update/'.$resturant->id)); ?>" method="POST" >
						 <?php echo csrf_field(); ?>

						<div class="form-group">
							<label for="name">Resturant Name</label>
							<input type="text" name="name" value="<?php echo e($resturant->name); ?>" class="form-control"/>
						</div>
						
						<div class="form-group">
							<label for="country">Resturant Address</label>
							<br>
							Coutry: <input type="text" name="country" value="<?php echo e($resturant->country); ?>"  class="form-control" />   
							City:   <input type="text" name="city"    value="<?php echo e($resturant->city); ?>"  class="form-control" />  
							address:<input type="text" name="address" value="<?php echo e($resturant->address); ?>"   class="form-control"/>   
						</div>
		
		
						<div class="form-group">
							<label for="tel">Returant Phone No.</label>
							<input type="text" name="tel" value="<?php echo e($resturant->tel); ?>"  class="form-control"/> 
						</div>
						
						<div class="form-group">
							<label for="tel">Resturant Type</label>
							
							
							
								<?php foreach( $resturantTypes as $resturantType ): ?> 
									<label class="checkbox-inline"> 	
									
										<!--checked the box for old value -->
										<?php if( in_array($resturantType ->id , explode(",", $resturant -> type) )   ): ?>	
											  <input type="checkbox" name="resturnatType[]" id=<?php echo e("resturnatType_" .  $resturantType ->id); ?> 
											  value=<?php echo e($resturantType ->id); ?> checked> 
											  <?php echo e($resturantType ->name); ?>

											  
										<?php else: ?>
											 <input type="checkbox" name="resturnatType[]" id=<?php echo e("resturnatType_" .  $resturantType ->id); ?> 
											  value=<?php echo e($resturantType ->id); ?> > 
											  <?php echo e($resturantType ->name); ?>

											  
										<?php endif; ?>	  
									</label>
 								<?php endforeach; ?>
							
							
							
						</div>
						
						<input type="submit" name="submit" value="Update Resturant"   class="btn btn-primary">
	

					</form>   

				</div>
			</div>
 		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>